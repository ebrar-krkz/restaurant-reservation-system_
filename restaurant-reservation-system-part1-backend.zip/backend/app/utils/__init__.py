"""
Utility functions
"""

